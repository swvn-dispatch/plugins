"""LDAP authentication backend used by the plugin hooks.

Handles:
  - LDAP server connection (plain, SSL, STARTTLS)
  - Service-account bind + user search
  - User bind for credential verification
  - Optional credential caching with TTL
  - JIT user provisioning in Django
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
import secrets
import sys
import time
from contextlib import contextmanager
from django.db import IntegrityError

logger = logging.getLogger(__name__)

# Add bundled vendor directory to import path so the shipped ldap3 is found.
_vendor_dir = os.path.join(os.path.dirname(__file__), "vendor")
if os.path.isdir(_vendor_dir) and _vendor_dir not in sys.path:
    sys.path.insert(0, _vendor_dir)

try:
    import ldap3  # noqa: F401
except ImportError:
    raise ImportError(
        "ldap3 is not bundled and not installed. "
        "Reinstall the LDAP Auth plugin or run: pip install ldap3"
    )

# In-memory auth cache: {cache_key: expiry_timestamp}
# Intentionally simple — cleared on plugin reload / container restart.
_auth_cache: dict = {}
MAX_CACHE_SIZE = 10_000  # Prevent OOM from credential-stuffing attacks

# Per-username failure tracking: {username: (fail_count, lockout_expiry)}
_failure_tracker: dict = {}
MAX_FAILURES = 5          # Lock out after this many consecutive failures
LOCKOUT_SECONDS = 300     # 5-minute lockout window

# Per-process HMAC key so cache hashes can't be cracked from a memory dump
_CACHE_HMAC_KEY = secrets.token_bytes(32)

LDAP_CONNECT_TIMEOUT = 10  # seconds


def _cache_key(username: str, password: str) -> str:
    """Derive a cache key from username + password without storing the password."""
    h = hmac.new(_CACHE_HMAC_KEY, f"{username}:{password}".encode("utf-8"), hashlib.sha256).hexdigest()
    return f"ldap_auth:{h}"


def check_cache(username: str, password: str, ttl: int) -> bool:
    """Return True if a recent successful auth is cached and still valid."""
    if ttl <= 0:
        return False
    key = _cache_key(username, password)
    expiry = _auth_cache.get(key)
    if expiry is not None and time.monotonic() < expiry:
        return True
    # Expired — remove stale entry
    _auth_cache.pop(key, None)
    return False


def set_cache(username: str, password: str, ttl: int) -> None:
    """Record a successful auth in the cache."""
    if ttl <= 0:
        return
    # Evict expired entries if cache is at capacity
    if len(_auth_cache) >= MAX_CACHE_SIZE:
        now = time.monotonic()
        expired = [k for k, v in _auth_cache.items() if now >= v]
        for k in expired:
            del _auth_cache[k]
    # If still full after eviction, refuse to grow further
    if len(_auth_cache) >= MAX_CACHE_SIZE:
        return
    key = _cache_key(username, password)
    _auth_cache[key] = time.monotonic() + ttl


def clear_cache() -> None:
    """Wipe the entire auth cache and failure tracker."""
    _auth_cache.clear()
    _failure_tracker.clear()


def _check_rate_limit(username: str) -> bool:
    """Return True if the username is currently locked out."""
    entry = _failure_tracker.get(username)
    if entry is None:
        return False
    fail_count, lockout_expiry = entry
    if fail_count >= MAX_FAILURES and time.monotonic() < lockout_expiry:
        return True
    # Lockout expired — clear it
    if time.monotonic() >= lockout_expiry:
        _failure_tracker.pop(username, None)
    return False


def _record_failure(username: str) -> None:
    """Record a failed auth attempt. Trigger lockout after MAX_FAILURES."""
    entry = _failure_tracker.get(username)
    if entry is None:
        _failure_tracker[username] = (1, time.monotonic() + LOCKOUT_SECONDS)
    else:
        count, _ = entry
        _failure_tracker[username] = (count + 1, time.monotonic() + LOCKOUT_SECONDS)
    # Bound tracker size
    if len(_failure_tracker) > MAX_CACHE_SIZE:
        oldest_key = next(iter(_failure_tracker))
        del _failure_tracker[oldest_key]


def _clear_failure(username: str) -> None:
    """Clear failure tracking on successful auth."""
    _failure_tracker.pop(username, None)


@contextmanager
def _ldap_connection(settings: dict):
    """Yield a bound ldap3 Connection (service-account bind), then unbind."""
    server_url = (settings.get("ldap_server_url") or "").strip()
    if not server_url:
        raise ValueError("LDAP Server URL is not configured")

    use_ssl = server_url.lower().startswith("ldaps://")

    server = ldap3.Server(server_url, use_ssl=use_ssl, get_info=ldap3.NONE, connect_timeout=LDAP_CONNECT_TIMEOUT)

    bind_dn = (settings.get("bind_dn") or "").strip()
    bind_password = settings.get("bind_password") or ""

    conn = ldap3.Connection(
        server,
        user=bind_dn or None,
        password=bind_password or None,
        auto_bind=False,
        raise_exceptions=True,
        read_only=True,
    )

    try:
        if settings.get("start_tls", False):
            conn.open()
            conn.start_tls()
        conn.bind()
        yield conn
    finally:
        try:
            conn.unbind()
        except Exception:
            pass


def _find_user_dn(conn, settings: dict, username: str) -> str | None:
    """Search for a user and return their DN, or None if not found."""
    search_base = (settings.get("user_search_base") or "").strip()
    if not search_base:
        raise ValueError("User Search Base is not configured")

    filter_template = settings.get(
        "user_search_filter",
        "(&(objectClass=person)(uid={username}))",
    )
    search_filter = filter_template.replace("{username}", ldap3.utils.conv.escape_filter_chars(username))

    scope_map = {
        "base": ldap3.BASE,
        "level": ldap3.LEVEL,
        "one": ldap3.LEVEL,
        "subtree": ldap3.SUBTREE,
    }
    scope = scope_map.get(
        (settings.get("search_scope") or "subtree").lower(),
        ldap3.SUBTREE,
    )

    conn.search(search_base, search_filter, search_scope=scope, attributes=["memberOf"])

    if not conn.entries:
        return None

    if len(conn.entries) > 1:
        logger.warning(
            "LDAP: search for '%s' returned %d entries; using first match (%s)",
            username, len(conn.entries), conn.entries[0].entry_dn,
        )

    return conn.entries[0].entry_dn


def _get_user_groups(conn, settings: dict, user_dn: str) -> list[str]:
    """Return a list of group DNs the user belongs to."""
    conn.search(user_dn, "(objectClass=*)", search_scope=ldap3.BASE, attributes=["memberOf"])

    if not conn.entries:
        return []

    try:
        return list(conn.entries[0]["memberOf"].values)
    except (KeyError, ldap3.core.exceptions.LDAPKeyError):
        return []


def _bind_as_user(settings: dict, user_dn: str, password: str) -> bool:
    """Attempt a simple bind as the user to verify their password."""
    # Reject empty passwords — some LDAP servers silently allow anonymous bind
    if not password:
        return False

    server_url = (settings.get("ldap_server_url") or "").strip()
    use_ssl = server_url.lower().startswith("ldaps://")

    server = ldap3.Server(server_url, use_ssl=use_ssl, get_info=ldap3.NONE, connect_timeout=LDAP_CONNECT_TIMEOUT)
    conn = ldap3.Connection(server, user=user_dn, password=password, auto_bind=False)

    try:
        if settings.get("start_tls", False):
            conn.open()
            conn.start_tls()
        if not conn.bind():
            return False
        return True
    except Exception:
        return False
    finally:
        try:
            conn.unbind()
        except Exception:
            pass


def authenticate(username: str, password: str, settings: dict):
    """Authenticate a user against LDAP and return a Django User or None.

    Flow:
      0. Validate input + check rate limit
      1. Check cache → return cached User if hit
      2. Service-account bind → search for user DN
      3. Bind as user → verify password
      4. JIT-create Django User if needed
      5. Cache successful result + clear failure tracker
    """
    if not username or not password:
        return None

    # Input validation
    if "\x00" in username or "\x00" in password:
        logger.warning("LDAP: null byte in credentials (user=%r)", username[:64])
        return None

    # Rate limiting
    if _check_rate_limit(username):
        logger.warning("LDAP: user '%s' is temporarily locked out after %d failed attempts", username, MAX_FAILURES)
        return None

    cache_ttl = int(settings.get("cache_ttl", 300))

    # 1. Cache check
    if check_cache(username, password, cache_ttl):
        return _get_django_user(username)

    # 2-3. LDAP search + bind
    try:
        with _ldap_connection(settings) as conn:
            user_dn = _find_user_dn(conn, settings, username)
            if user_dn is None:
                logger.debug("LDAP: user '%s' not found", username)
                _record_failure(username)
                return None

            if not _bind_as_user(settings, user_dn, password):
                logger.debug("LDAP: bind failed for user '%s'", username)
                _record_failure(username)
                return None

            # Read group memberships for level mapping
            groups = []
            admin_group_dn = (settings.get("admin_group_dn") or "").strip()
            standard_group_dn = (settings.get("standard_group_dn") or "").strip()
            if admin_group_dn or standard_group_dn:
                groups = _get_user_groups(conn, settings, user_dn)

    except Exception:
        logger.error("LDAP authentication error for '%s'", username, exc_info=True)
        return None

    # 4. Get or create Django user
    user = _get_or_create_user(username, settings, groups)
    if user is None:
        return None

    # 5. Cache + clear failures
    set_cache(username, password, cache_ttl)
    _clear_failure(username)

    return user


def _get_django_user(username: str):
    """Look up an existing Django User by username."""
    from apps.accounts.models import User
    try:
        return User.objects.get(username=username)
    except User.DoesNotExist:
        return None


def _get_or_create_user(username: str, settings: dict, groups: list[str]):
    """Return an existing Django User, or create one if auto_create_users is enabled."""
    from apps.accounts.models import User

    try:
        user = User.objects.get(username=username)
        # Update admin status based on current group membership
        _sync_user_level(user, settings, groups)
        return user
    except User.DoesNotExist:
        pass

    if not settings.get("auto_create_users", True):
        logger.debug("LDAP: user '%s' not in Dispatcharr and auto-create disabled", username)
        return None

    # Determine user level: default Streamer (0), Standard (1) by group, Admin (10) by group
    user_level = 0
    standard_group_dn = (settings.get("standard_group_dn") or "").strip().lower()
    admin_group_dn = (settings.get("admin_group_dn") or "").strip().lower()
    lower_groups = [g.lower() for g in groups]
    if admin_group_dn and admin_group_dn in lower_groups:
        user_level = 10
    elif standard_group_dn and standard_group_dn in lower_groups:
        user_level = 1

    try:
        user = User.objects.create_user(username=username, password=None)
        user.user_level = user_level
        user.first_name = username
        user.last_name = "LDAP"
        user.stream_limit = int(settings.get("default_stream_limit", 0))

        # Set xc_password to a sentinel so XC is "enabled" but not guessable
        props = user.custom_properties or {}
        props["xc_password"] = f"LDAP-{secrets.token_hex(24)}"
        user.custom_properties = props

        user.save()

        # Assign default channel profiles
        profile_names = (settings.get("default_channel_profiles") or "").strip()
        if profile_names:
            from apps.channels.models import ChannelProfile
            names = [n.strip() for n in profile_names.split(",") if n.strip()]
            profiles = ChannelProfile.objects.filter(name__in=names)
            if profiles.exists():
                user.channel_profiles.set(profiles)

        logger.info("LDAP: created Dispatcharr user '%s' (level=%d, stream_limit=%d)", username, user_level, user.stream_limit)
        return user
    except IntegrityError:
        # Race condition: another request created this user concurrently
        logger.debug("LDAP: user '%s' was created by a concurrent request", username)
        try:
            return User.objects.get(username=username)
        except User.DoesNotExist:
            return None
    except Exception:
        logger.error("LDAP: failed to create user '%s'", username, exc_info=True)
        return None


def _sync_user_level(user, settings: dict, groups: list[str]) -> None:
    """Sync user level based on current LDAP group membership."""
    admin_group_dn = (settings.get("admin_group_dn") or "").strip().lower()
    standard_group_dn = (settings.get("standard_group_dn") or "").strip().lower()
    if not admin_group_dn and not standard_group_dn:
        return

    lower_groups = [g.lower() for g in groups]

    if admin_group_dn and admin_group_dn in lower_groups:
        if user.user_level != 10:
            user.user_level = 10
            user.save(update_fields=["user_level"])
            logger.info("LDAP: promoted '%s' to Admin via group membership", user.username)
    elif standard_group_dn and standard_group_dn in lower_groups:
        if user.user_level != 1:
            user.user_level = 1
            user.save(update_fields=["user_level"])
            logger.info("LDAP: set '%s' to Standard via group membership", user.username)
    else:
        if user.user_level != 0:
            user.user_level = 0
            user.save(update_fields=["user_level"])
            logger.info("LDAP: demoted '%s' to Streamer (not in any mapped group)", user.username)


def test_connection(settings: dict) -> dict:
    """Test LDAP connectivity. Returns a result dict for the plugin action."""
    try:
        with _ldap_connection(settings) as conn:
            return {
                "status": "success",
                "message": (
                    f"Connected to {settings.get('ldap_server_url')} | "
                    f"Bound as: {conn.user or 'anonymous'}"
                ),
            }
    except Exception as e:
        return {"status": "error", "message": f"Connection failed: {e}"}


def test_login(username: str, password: str, settings: dict) -> dict:
    """Test a specific user's LDAP authentication. Returns a result dict."""
    if not username or not password:
        return {"status": "error", "message": "Username and password are required"}

    try:
        with _ldap_connection(settings) as conn:
            user_dn = _find_user_dn(conn, settings, username)
            if user_dn is None:
                return {"status": "error", "message": f"User '{username}' not found in LDAP"}

            if not _bind_as_user(settings, user_dn, password):
                return {"status": "error", "message": f"Bind failed for '{username}' (wrong password?)"}

            groups = []
            admin_group_dn = (settings.get("admin_group_dn") or "").strip()
            if admin_group_dn:
                groups = _get_user_groups(conn, settings, user_dn)

            is_admin = admin_group_dn and any(
                g.lower() == admin_group_dn.lower() for g in groups
            )
            level_label = "Admin" if is_admin else f"Level {settings.get('default_user_level', 0)}"

            return {
                "status": "success",
                "message": (
                    f"User '{username}' authenticated successfully | "
                    f"DN: {user_dn} | "
                    f"Groups: {len(groups)} | "
                    f"Would be: {level_label}"
                ),
            }
    except Exception as e:
        return {"status": "error", "message": f"Test failed: {e}"}
