"""Anonymous YouTube live metadata with shared Redis-backed poll state."""

from __future__ import annotations

import json
import logging
import re
import secrets
import time

import requests

from .stream_sources import StreamSnapshot, source_url

logger = logging.getLogger(__name__)

LIVE_URL = "https://www.youtube.com/@{handle}/live"
STATE_PREFIX = "twitcharr:youtube:v1:state:"
LEASE_PREFIX = "twitcharr:youtube:v1:lease:"
FRESH_SECONDS = 120
STATE_TTL_SECONDS = 86400
USER_AGENT = "Mozilla/5.0 (compatible; Twitcharr/1.0)"


def _extract_assignment(html: str, name: str) -> dict | None:
    match = re.search(rf"(?:var\s+)?{re.escape(name)}\s*=\s*", html)
    if not match:
        return None
    start = html.find("{", match.end())
    if start < 0:
        return None
    try:
        value, _ = json.JSONDecoder().raw_decode(html[start:])
    except json.JSONDecodeError:
        return None
    return value if isinstance(value, dict) else None


def _find_value(value, key: str):
    if isinstance(value, dict):
        if key in value:
            return value[key]
        for child in value.values():
            found = _find_value(child, key)
            if found is not None:
                return found
    elif isinstance(value, list):
        for child in value:
            found = _find_value(child, key)
            if found is not None:
                return found
    return None


def _text(value) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        return str(value.get("simpleText") or "").strip()
    return ""


def _thumbnail(value) -> str:
    thumbnails = (value or {}).get("thumbnails") if isinstance(value, dict) else None
    if not isinstance(thumbnails, list):
        return ""
    return str((thumbnails[-1] or {}).get("url") or "") if thumbnails else ""


def _owner_avatar(initial: dict | None) -> str:
    """Return the watched video's owner avatar, not an unrelated recommendation."""
    secondary = _find_value(initial, "videoSecondaryInfoRenderer") if initial else None
    owner = (secondary or {}).get("owner", {}).get("videoOwnerRenderer", {})
    return _thumbnail(owner.get("thumbnail"))


def snapshot_from_html(handle: str, html: str) -> StreamSnapshot | None:
    """Return a normalized observation, or None for an ambiguous page."""
    player = _extract_assignment(html, "ytInitialPlayerResponse")
    initial = _extract_assignment(html, "ytInitialData")
    if not player:
        return None
    details = player.get("videoDetails") or {}
    microformat = (player.get("microformat") or {}).get("playerMicroformatRenderer") or {}
    channel_id = str(details.get("channelId") or microformat.get("externalChannelId") or "")
    canonical = str(microformat.get("ownerProfileUrl") or "")
    if not channel_id or (canonical and f"@{handle.lower()}" not in canonical.lower()):
        return None
    is_live = details.get("isLive") is True
    live_details = microformat.get("liveBroadcastDetails") or {}
    # `videoDetails.isLive` is the primary signal. Some valid live pages omit
    # liveBroadcastDetails, but an explicit contradiction remains ambiguous.
    if live_details.get("isLiveNow") is not None and is_live != (live_details.get("isLiveNow") is True):
        return None
    author = str(details.get("author") or handle)
    avatar = _owner_avatar(initial) or (_thumbnail(_find_value(initial, "avatar")) if initial else "")
    video_id = str(details.get("videoId") or "")
    if is_live and not video_id:
        return None
    return StreamSnapshot(
        platform="youtube",
        slug=handle,
        display_name=author,
        live_state="live" if is_live else "offline",
        source_url=source_url("youtube", handle),
        description=_text(microformat.get("description")),
        profile_image_url=avatar,
        stream_title=str(details.get("title") or "") if is_live else "",
        category=_text(microformat.get("category")),
        started_at=str(live_details.get("startTimestamp") or "") if is_live else "",
        viewer_count=int(str(details.get("viewCount") or "0")) if is_live else 0,
        program_image_url=_thumbnail(details.get("thumbnail")),
        provider_channel_id=channel_id,
        active_stream_id=video_id if is_live else "",
    )


def live_fallback_from_html(handle: str, html: str) -> StreamSnapshot | None:
    """Recognize a live page when YouTube changes its JSON wrapper format."""
    if not re.search(r'"isLive"\s*:\s*true', html):
        return None
    video_match = re.search(r'"videoId"\s*:\s*"([^"]+)"', html)
    title_match = re.search(r'<meta[^>]+property="og:title"[^>]+content="([^"]+)"', html)
    return StreamSnapshot(
        platform="youtube",
        slug=handle,
        display_name=handle,
        live_state="live",
        source_url=source_url("youtube", handle),
        stream_title=title_match.group(1) if title_match else "",
        active_stream_id=video_match.group(1) if video_match else "",
    )


def _serialize(snapshot: StreamSnapshot) -> dict:
    return dict(snapshot.__dict__)


def _deserialize(data: dict) -> StreamSnapshot | None:
    try:
        return StreamSnapshot(**data)
    except (TypeError, ValueError):
        return None


class YouTubeClient:
    def __init__(self, session: requests.Session | None = None, *, timeout: int = 10):
        self.session = session or requests.Session()
        self.timeout = timeout

    def poll(self, handle: str) -> StreamSnapshot | None:
        try:
            response = self.session.get(
                LIVE_URL.format(handle=handle),
                headers={"User-Agent": USER_AGENT},
                timeout=self.timeout,
                allow_redirects=True,
            )
            if response.status_code != 200:
                return None
            snapshot = snapshot_from_html(handle, response.text)
            used_fallback = False
            if snapshot is None:
                snapshot = live_fallback_from_html(handle, response.text)
                used_fallback = snapshot is not None
            if snapshot is None:
                logger.warning(
                    "YouTube live page for @%s had no usable metadata (status=%d, url=%s, bytes=%d)",
                    handle,
                    response.status_code,
                    response.url,
                    len(response.text),
                )
            elif used_fallback:
                logger.info("YouTube live fallback used for @%s", handle)
            return snapshot
        except requests.RequestException:
            logger.warning("YouTube live metadata request failed for @%s", handle)
            return None


class YouTubeStateRepository:
    """Coordinates one poll per handle across Dispatcharr workers."""
    def __init__(self, redis=None, *, now=time.time):
        self.redis = redis
        self.now = now

    def _redis(self):
        if self.redis is not None:
            return self.redis
        from django_redis import get_redis_connection

        return get_redis_connection("default")

    def get(self, handle: str, client: YouTubeClient) -> StreamSnapshot:
        handle = handle.lower()
        state_key = f"{STATE_PREFIX}{handle}"
        lease_key = f"{LEASE_PREFIX}{handle}"
        now = self.now()
        try:
            redis = self._redis()
            raw = redis.get(state_key)
            state = json.loads(raw) if raw else {}
            cached = _deserialize(state.get("snapshot") or {})
            if cached and state.get("fresh_until", 0) > now:
                return cached
            token = secrets.token_urlsafe(16)
            if not redis.set(lease_key, token, nx=True, px=30_000):
                return self._unknown(handle, cached)
            try:
                raw = redis.get(state_key)
                state = json.loads(raw) if raw else {}
                cached = _deserialize(state.get("snapshot") or {})
                if cached and state.get("fresh_until", 0) > now:
                    return cached
                snapshot = client.poll(handle)
                if snapshot:
                    state = {
                        "version": 1,
                        "snapshot": _serialize(snapshot),
                        "fresh_until": now + FRESH_SECONDS,
                        "last_attempt": now,
                        "last_success": now,
                        "failures": 0,
                    }
                    redis.set(state_key, json.dumps(state), ex=STATE_TTL_SECONDS)
                    return snapshot
                failures = int(state.get("failures") or 0) + 1
                state.update({"version": 1, "last_attempt": now, "failures": failures, "fresh_until": 0})
                redis.set(state_key, json.dumps(state), ex=STATE_TTL_SECONDS)
                return self._unknown(handle, cached)
            finally:
                if redis.get(lease_key) in {token, token.encode()}:
                    redis.delete(lease_key)
        except Exception:
            logger.exception("YouTube Redis state is unavailable for @%s", handle)
            return self._unknown(handle, None)

    def clear(self) -> int:
        """Remove only Twitcharr's versioned YouTube state during uninstall."""
        try:
            redis = self._redis()
            keys = list(redis.scan_iter(match=f"{STATE_PREFIX}*")) + list(redis.scan_iter(match=f"{LEASE_PREFIX}*"))
            return int(redis.delete(*keys)) if keys else 0
        except Exception:
            logger.exception("Could not remove Twitcharr YouTube Redis state")
            return 0

    @staticmethod
    def _unknown(handle: str, prior: StreamSnapshot | None) -> StreamSnapshot:
        if prior:
            prior.live_state = "unknown"
            prior.active_stream_id = ""
            prior.stream_title = ""
            prior.viewer_count = 0
            return prior
        return StreamSnapshot("youtube", handle, handle, "unknown", source_url("youtube", handle))
