"""One-time migration for config keys our fork renamed after upstream shipped
its own version of the same feature under a different key.

Kept in its own file, called from a single site in ``plugin.py``
(``_load_settings``), so that future upstream syncs only need to check that
one call still applies instead of hunting through the rest of the plugin.
See ``UPSTREAM_SYNC.md`` for the process.

Each entry in ``LEGACY_KEY_MIGRATIONS`` maps an old key our fork used to a
``(new_key, value_mapper)`` pair. ``value_mapper`` takes the old raw value and
returns the value to store under the new key, chosen to preserve the
*effective behavior* the user already had configured (not necessarily
upstream's own default for the new key).
"""

from __future__ import annotations

from typing import Any, Callable

# emoji -> emoji, tag -> xmltv, both -> both, none -> none.
_LIVE_INDICATOR_VALUES = {
    "emoji": "emoji",
    "tag": "xmltv",
    "both": "both",
    "none": "none",
}


def _migrate_live_indicator(value: Any) -> str:
    normalized = str(value).strip().lower() if value is not None else ""
    return _LIVE_INDICATOR_VALUES.get(normalized, "xmltv")


def _migrate_channel_logo_mode(value: Any) -> str:
    # Old setting defaulted to False (category/box-art first, matching the
    # pre-existing behavior). Upstream's new default for channel_logo_mode is
    # "profile", which is a different default — so this must always write an
    # explicit value rather than letting the new key's default apply.
    return "profile" if bool(value) else "category"


LEGACY_KEY_MIGRATIONS: dict[str, tuple[str, Callable[[Any], Any]]] = {
    "live_indicator": ("live_indicator_mode", _migrate_live_indicator),
    "use_channel_avatar_logo": ("channel_logo_mode", _migrate_channel_logo_mode),
}


def migrate_legacy_settings(raw: dict) -> tuple[dict, bool]:
    """Translate any old-fork keys present in `raw` to their upstream keys.

    Returns `(settings, changed)`. Only acts on keys that are actually present
    in `raw` (i.e. a real prior install), and only when the new key isn't
    already set explicitly, so this is safe to call unconditionally on every
    settings load.
    """
    settings = dict(raw or {})
    changed = False
    for old_key, (new_key, mapper) in LEGACY_KEY_MIGRATIONS.items():
        if old_key not in settings:
            continue
        if new_key not in settings:
            settings[new_key] = mapper(settings[old_key])
            changed = True
        del settings[old_key]
        changed = True
    return settings, changed
