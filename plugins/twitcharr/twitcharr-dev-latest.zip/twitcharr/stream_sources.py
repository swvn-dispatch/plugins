"""Provider-neutral channel identities and normalized stream observations."""

from __future__ import annotations

from dataclasses import dataclass


PLATFORMS = frozenset({"twitch", "youtube", "kick"})


def normalize_platform(value: str | None) -> str:
    platform = (value or "twitch").strip().lower()
    if platform not in PLATFORMS:
        raise ValueError(f"Unsupported stream platform: {platform}")
    return platform


def canonical_key(platform: str, slug: str) -> str:
    return f"{normalize_platform(platform)}:{slug.strip().lower()}"


def tvg_id(platform: str, slug: str) -> str:
    prefixes = {"twitch": "twitch", "youtube": "youtube", "kick": "kick"}
    return f"{prefixes[normalize_platform(platform)]}.{slug.strip().lower()}"


def source_url(platform: str, slug: str) -> str:
    slug = slug.strip().lower()
    platform = normalize_platform(platform)
    if platform == "youtube":
        return f"https://www.youtube.com/@{slug}/live"
    if platform == "kick":
        return f"https://kick.com/{slug}"
    return f"https://twitch.tv/{slug}"


@dataclass(frozen=True)
class ChannelReference:
    platform: str
    slug: str
    profiles: tuple[str, ...] = ()
    group: str = ""

    @property
    def key(self) -> str:
        return canonical_key(self.platform, self.slug)

    @property
    def tvg_id(self) -> str:
        return tvg_id(self.platform, self.slug)


@dataclass
class StreamSnapshot:
    platform: str
    slug: str
    display_name: str
    live_state: str
    source_url: str
    description: str = ""
    profile_image_url: str = ""
    stream_title: str = ""
    category: str = ""
    started_at: str = ""
    viewer_count: int = 0
    program_image_url: str = ""
    provider_channel_id: str = ""
    active_stream_id: str = ""

    @property
    def live(self) -> bool:
        return self.live_state == "live"

    @property
    def tvg_id(self) -> str:
        return tvg_id(self.platform, self.slug)
