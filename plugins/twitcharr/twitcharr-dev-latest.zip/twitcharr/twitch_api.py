"""No-login Twitch metadata client for the Twitcharr plugin.

Uses the public Twitch web GraphQL endpoint (the same one Streamlink's Twitch
plugin uses for anonymous metadata lookups). No Client ID, no OAuth.

Provides three layers:
  * `TwitchClient.get_users / get_streams / get_games` — channel metadata used
    by the EPG builder.
  * `discover_logins(spec)` — turns user-friendly tokens like
    `game:Just Chatting:10` or `top:de:25` into a deduplicated list of logins.
  * `parse_login_list(text)` — accepts plain logins, full URLs, and discovery
    tokens mixed together in one textarea.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass
from typing import Iterable, Sequence

import requests

logger = logging.getLogger(__name__)

GQL_URL = "https://gql.twitch.tv/gql"
OAUTH_VALIDATE_URL = "https://id.twitch.tv/oauth2/validate"
OAUTH_DEVICE_URL = "https://id.twitch.tv/oauth2/device"
OAUTH_TOKEN_URL = "https://id.twitch.tv/oauth2/token"
HELIX_FOLLOWED_CHANNELS_URL = "https://api.twitch.tv/helix/channels/followed"
PUBLIC_CLIENT_ID = "kimne78kx3ncx6brgo4mv6wki5h1ko"
# Twitch's anonymous GraphQL endpoint can silently truncate larger batched
# channel lookups. Ten keeps configured lineups complete without extra auth.
GQL_BATCH = 10
DEFAULT_TIMEOUT = 15
BOX_ART_SIZE_RE = re.compile(r"-\d+x\d+(?=\.[a-zA-Z0-9]+(?:\?|$))")
# Trailing "(profile1, profile2)" on any channels-field token assigns the
# resolved channels to those Dispatcharr channel profiles. The "(" must
# follow the token without a space: that keeps category names like
# "game:Tomb Raider (2013)" intact while still matching "gronkh(family)".
PROFILE_SUFFIX_RE = re.compile(r"^(?P<base>.*?\S)\((?P<profiles>[^()]*)\)\s*$")
GROUP_SUFFIX_RE = re.compile(r"^(?P<base>.*?\S)\[(?P<group>[^\[\]]+)\]\s*$")

CHANNEL_QUERY = """
query Twitcharr($login: String!) {
  user(login: $login) {
    id
    login
    displayName
    description
    profileImageURL(width: 300)
    stream {
      id
      title
      createdAt
      viewersCount
      type
      previewImageURL(width: 640, height: 360)
      game {
        id
        name
        boxArtURL(width: 272, height: 380)
      }
    }
  }
}
"""

GAME_STREAMS_QUERY = """
query TwitcharrGameStreams($name: String!, $limit: Int!) {
  game(name: $name) {
    streams(first: $limit, options: {sort: VIEWER_COUNT}) {
      edges {
        node {
          broadcaster { login }
          viewersCount
          title
        }
      }
    }
  }
}
"""

TOP_STREAMS_QUERY = """
query TwitcharrTopStreams($limit: Int!, $languages: [Language!]) {
  streams(first: $limit, options: {sort: VIEWER_COUNT, languages: $languages}) {
    edges {
      node {
        broadcaster { login }
        viewersCount
        title
      }
    }
  }
}
"""

SEARCH_CHANNELS_QUERY = """
query TwitcharrSearchChannels($query: String!, $limit: Int!) {
  searchFor(userQuery: $query, platform: "web", target: {limit: $limit}) {
    channels {
      edges {
        item {
          login
          displayName
          followers { totalCount }
        }
      }
    }
  }
}
"""


@dataclass
class TwitchUser:
    id: str
    login: str
    display_name: str
    description: str = ""
    profile_image_url: str = ""


@dataclass
class TwitchStream:
    user_id: str
    user_login: str
    user_name: str
    title: str = ""
    game_id: str = ""
    game_name: str = ""
    started_at: str = ""
    viewer_count: int = 0
    thumbnail_url: str = ""
    is_live: bool = True


@dataclass
class TwitchGame:
    id: str
    name: str
    box_art_url: str = ""


class TwitchClient:
    def __init__(self, *, session: requests.Session | None = None):
        self._session = session or requests.Session()
        self._users: dict[str, TwitchUser] = {}
        self._streams: dict[str, TwitchStream] = {}
        self._games: dict[str, TwitchGame] = {}
        self._fetched_logins: set[str] = set()
        self.failed_logins: set[str] = set()
        self.discovery_failed = False

    def _headers(self) -> dict:
        return {
            "Client-ID": PUBLIC_CLIENT_ID,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 Twitcharr",
        }

    def _post_gql(self, payload) -> list[dict]:
        single = isinstance(payload, dict)
        body = [payload] if single else payload
        for attempt in range(3):
            resp = self._session.post(
                GQL_URL,
                headers=self._headers(),
                json=body,
                timeout=DEFAULT_TIMEOUT,
            )
            if resp.status_code == 429:
                wait = 2.0 * (attempt + 1)
                logger.warning("Twitch GraphQL rate-limit hit, sleeping %.1fs", wait)
                time.sleep(wait)
                continue
            if resp.status_code >= 500 and attempt < 2:
                time.sleep(1.0 * (attempt + 1))
                continue
            if resp.status_code != 200:
                raise RuntimeError(
                    f"Twitch GraphQL request failed ({resp.status_code}): {resp.text[:200]}"
                )
            data = resp.json()
            if isinstance(data, dict):
                data = [data]
            if not isinstance(data, list):
                raise RuntimeError("Twitch GraphQL returned an unexpected payload")
            return data
        raise RuntimeError("Twitch GraphQL request failed after retries")

    def validate_access_token(self, token: str) -> dict | None:
        """Return safe OAuth metadata for a user token, or None when invalid."""
        token = _clean_access_token(token)
        if not token:
            return None
        try:
            response = self._session.get(
                OAUTH_VALIDATE_URL,
                headers={"Authorization": f"OAuth {token}"},
                timeout=DEFAULT_TIMEOUT,
            )
            if response.status_code != 200:
                logger.warning("Twitch access token validation failed (%s)", response.status_code)
                return None
            data = response.json()
            if not isinstance(data, dict):
                return None
            return data
        except Exception:
            logger.exception("Twitch access token validation failed")
            return None

    def followed_channels(self, token: str) -> list[str]:
        """Return every broadcaster followed by the user represented by token."""
        token = _clean_access_token(token)
        metadata = self.validate_access_token(token)
        if not metadata:
            self.discovery_failed = True
            return []

        scopes = {str(scope).lower() for scope in metadata.get("scopes") or []}
        client_id = str(metadata.get("client_id") or "").strip()
        user_id = str(metadata.get("user_id") or "").strip()
        if not client_id or not user_id or "user:read:follows" not in scopes:
            logger.warning("Twitch following discovery needs a user token with user:read:follows")
            self.discovery_failed = True
            return []

        logins: list[str] = []
        seen: set[str] = set()
        cursor = ""
        try:
            while True:
                params = {"user_id": user_id, "first": 100}
                if cursor:
                    params["after"] = cursor
                response = self._session.get(
                    HELIX_FOLLOWED_CHANNELS_URL,
                    params=params,
                    headers={"Authorization": f"Bearer {token}", "Client-Id": client_id},
                    timeout=DEFAULT_TIMEOUT,
                )
                if response.status_code != 200:
                    logger.warning("Twitch followed channels request failed (%s)", response.status_code)
                    self.discovery_failed = True
                    return []
                data = response.json()
                if not isinstance(data, dict):
                    self.discovery_failed = True
                    return []
                for channel in data.get("data") or []:
                    login = str((channel or {}).get("broadcaster_login") or "").strip().lower()
                    if login and login not in seen:
                        seen.add(login)
                        logins.append(login)
                cursor = str(((data.get("pagination") or {}).get("cursor") or "")).strip()
                if not cursor:
                    return logins
        except Exception:
            logger.exception("Twitch followed channels discovery failed")
            self.discovery_failed = True
            return []

    def refresh_following_access_token(self, client_id: str, refresh_token: str) -> tuple[str, str, int]:
        """Exchange a following refresh token for an in-memory access token."""
        refresh_token = (refresh_token or "").strip()
        result = self.refresh_access_token(client_id, refresh_token)
        if result.get("_status_code") != 200:
            oauth_status = str(result.get("message") or result.get("error") or "").strip().lower()
            if "invalid refresh token" in oauth_status:
                logger.warning("Twitch following refresh token is invalid or has already been used")
            elif "invalid client" in oauth_status:
                logger.warning("Twitch following refresh rejected the Client ID or requires a public Twitch application")
            else:
                logger.warning("Twitch following refresh failed (%s)", result.get("_status_code"))
            self.discovery_failed = True
            return "", "", 0
        access_token = str(result.get("access_token") or "").strip()
        rotated_refresh_token = str(result.get("refresh_token") or "").strip()
        if not access_token or not rotated_refresh_token:
            logger.warning("Twitch following refresh returned incomplete credentials")
            self.discovery_failed = True
            return "", "", 0
        metadata = self.validate_access_token(access_token)
        scopes = {str(scope).lower() for scope in (metadata or {}).get("scopes") or []}
        if not metadata or not metadata.get("client_id") or not metadata.get("user_id") or "user:read:follows" not in scopes:
            logger.warning("Twitch following refresh did not grant a usable user token")
            self.discovery_failed = True
            return "", "", 0
        return access_token, rotated_refresh_token, int(metadata.get("expires_in") or 0)

    def start_device_authorization(self, client_id: str) -> dict:
        return self._post_oauth_form(
            OAUTH_DEVICE_URL,
            {"client_id": client_id, "scopes": "user:read:follows"},
        )

    def finish_device_authorization(self, client_id: str, device_code: str) -> dict:
        return self._post_oauth_form(
            OAUTH_TOKEN_URL,
            {
                "client_id": client_id,
                "device_code": device_code,
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "scopes": "user:read:follows",
            },
        )

    def refresh_access_token(self, client_id: str, refresh_token: str) -> dict:
        return self._post_oauth_form(
            OAUTH_TOKEN_URL,
            {
                "client_id": client_id,
                "refresh_token": refresh_token,
                "grant_type": "refresh_token",
            },
        )

    def _post_oauth_form(self, url: str, data: dict) -> dict:
        try:
            response = self._session.post(url, data=data, timeout=DEFAULT_TIMEOUT)
            payload = response.json()
            if not isinstance(payload, dict):
                payload = {}
            payload["_status_code"] = response.status_code
            return payload
        except Exception:
            logger.exception("Twitch OAuth request failed")
            return {"_status_code": 0, "error": "request_failed"}

    # ------------------------------------------------------------------ users
    def _fetch_channels(self, logins: Sequence[str]) -> None:
        clean = [login.strip().lower() for login in logins if login and login.strip()]
        missing = [login for login in clean if login not in self._fetched_logins]
        for batch in _chunks(missing, GQL_BATCH):
            payload = [
                {
                    "operationName": "Twitcharr",
                    "variables": {"login": login},
                    "query": CHANNEL_QUERY,
                }
                for login in batch
            ]
            responses = self._post_gql(payload)
            if len(responses) < len(batch):
                self.failed_logins.update(batch[len(responses):])
            for login, item in zip(batch, responses):
                self._fetched_logins.add(login)
                errors = item.get("errors") or []
                if errors:
                    logger.warning("Twitch GraphQL warning for %s: %s", login, errors[:1])
                    self.failed_logins.add(login)
                    continue
                user = ((item.get("data") or {}).get("user") or None)
                if not user:
                    logger.warning("Twitch channel not found: %s", login)
                    continue

                normalized_login = (user.get("login") or login).lower()
                twitch_user = TwitchUser(
                    id=str(user.get("id") or ""),
                    login=normalized_login,
                    display_name=user.get("displayName") or normalized_login,
                    description=user.get("description") or "",
                    profile_image_url=user.get("profileImageURL") or "",
                )
                self._users[normalized_login] = twitch_user

                stream = user.get("stream")
                if stream:
                    game = stream.get("game") or {}
                    game_id = str(game.get("id") or "")
                    if game_id:
                        self._games[game_id] = TwitchGame(
                            id=game_id,
                            name=game.get("name") or "",
                            box_art_url=game.get("boxArtURL") or "",
                        )
                    self._streams[normalized_login] = TwitchStream(
                        user_id=twitch_user.id,
                        user_login=normalized_login,
                        user_name=twitch_user.display_name,
                        title=stream.get("title") or "",
                        game_id=game_id,
                        game_name=game.get("name") or "",
                        started_at=stream.get("createdAt") or "",
                        viewer_count=int(stream.get("viewersCount") or 0),
                        thumbnail_url=stream.get("previewImageURL") or "",
                        is_live=True,
                    )

    def get_users(self, logins: Sequence[str]) -> dict[str, TwitchUser]:
        self._fetch_channels(logins)
        return {login: self._users[login] for login in _lower_existing(logins, self._users)}

    def get_streams(self, user_logins: Sequence[str]) -> dict[str, TwitchStream]:
        self._fetch_channels(user_logins)
        return {login: self._streams[login] for login in _lower_existing(user_logins, self._streams)}

    def get_games(self, ids: Iterable[str]) -> dict[str, TwitchGame]:
        return {str(gid): self._games[str(gid)] for gid in ids if str(gid) in self._games}

    # ------------------------------------------------------------------ discovery
    def streams_in_game(self, name: str, *, limit: int = 10) -> list[str]:
        """Return logins of the top-`limit` live streams in a Twitch category."""
        if not name:
            return []
        try:
            data = self._post_gql({
                "operationName": "TwitcharrGameStreams",
                "variables": {"name": name, "limit": int(max(1, min(100, limit)))},
                "query": GAME_STREAMS_QUERY,
            })
        except Exception:
            logger.exception("Twitch game-streams discovery failed for %r", name)
            self.discovery_failed = True
            return []
        edges = (((data or [{}])[0].get("data") or {}).get("game") or {}).get("streams") or {}
        out: list[str] = []
        for edge in edges.get("edges", []) or []:
            login = (((edge or {}).get("node") or {}).get("broadcaster") or {}).get("login")
            if login:
                out.append(str(login).lower())
        return out

    def top_streams(self, *, languages: Sequence[str] = (), limit: int = 25) -> list[str]:
        """Top live streams globally, optionally filtered by language code (de/en/...)."""
        try:
            variables: dict = {"limit": int(max(1, min(100, limit)))}
            if languages:
                variables["languages"] = [language.upper() for language in languages if language]
            else:
                variables["languages"] = None
            data = self._post_gql({
                "operationName": "TwitcharrTopStreams",
                "variables": variables,
                "query": TOP_STREAMS_QUERY,
            })
        except Exception:
            logger.exception("Twitch top-streams discovery failed (lang=%r)", languages)
            self.discovery_failed = True
            return []
        edges = (((data or [{}])[0].get("data") or {}).get("streams") or {}).get("edges") or []
        out: list[str] = []
        for edge in edges:
            login = (((edge or {}).get("node") or {}).get("broadcaster") or {}).get("login")
            if login:
                out.append(str(login).lower())
        return out

    def search_channels(self, query: str, *, limit: int = 10) -> list[str]:
        """Smooth-typing search: maps a free-text query to the best matching logins."""
        if not query:
            return []
        try:
            data = self._post_gql({
                "operationName": "TwitcharrSearchChannels",
                "variables": {"query": query, "limit": int(max(1, min(50, limit)))},
                "query": SEARCH_CHANNELS_QUERY,
            })
        except Exception:
            logger.exception("Twitch channel search failed for %r", query)
            self.discovery_failed = True
            return []
        channels = (((data or [{}])[0].get("data") or {}).get("searchFor") or {}).get("channels") or {}
        out: list[str] = []
        for edge in channels.get("edges", []) or []:
            login = ((edge or {}).get("item") or {}).get("login")
            if login:
                out.append(str(login).lower())
        return out


# ---------------------------------------------------------------------------
# Free-text input parsing
# ---------------------------------------------------------------------------

def _chunks(seq: Sequence[str], size: int):
    for i in range(0, len(seq), size):
        yield seq[i : i + size]


def _lower_existing(logins: Iterable[str], values: dict) -> list[str]:
    return [login.strip().lower() for login in logins if login and login.strip().lower() in values]


def _clean_access_token(token: str) -> str:
    token = (token or "").strip()
    if token.lower().startswith("oauth:"):
        token = token[6:]
    return token.strip()


def parse_login_list(raw: str) -> list[dict]:
    """Parse the textarea content into a list of resolution items.

    Returns a list of dicts. Each dict is one of:
        {"type": "login", "value": "<login>"}
        {"type": "game",  "value": "<category name>", "limit": int}
        {"type": "top",   "languages": ["de"], "limit": int}
        {"type": "search","value": "<free text>", "limit": int}
        {"type": "following", "token": "<refresh token>"}

    Any item may additionally carry {"profiles": ["profile1", ...]} and a
    "group" name from trailing `(profiles)` and `[group]` suffixes.

    Input can be separated by new lines or commas:
        gronkh, papaplatte(family), knossi

    Discovery tokens accepted (case-insensitive on the prefix):
        game:Just Chatting           -> top 10 streams in that category
        game:Just Chatting:25        -> top 25
        top                          -> 10 globally
        top:25                       -> 25 globally
        top:de:25                    -> top 25 German
        search:gronkh                -> first 10 search hits
        search:gronkh:5              -> first 5 hits
        following:<refresh token>     -> every followed channel

    Channel-profile suffix (works on logins and discovery tokens; no space
    before the parenthesis, so names like "game:Tomb Raider (2013)" survive):
        gronkh(family)               -> add channel to profile "family"
        top:de:25(Livestreams, TV)   -> add all 25 to both profiles
        following:<refresh token> (Family) -> add followed channels to Family
        gronkh(Family)[Gaming]         -> add channel to Family and Gaming
    """
    if not raw:
        return []
    items: list[dict] = []
    for t in _iter_input_tokens(raw):
        parsed = _parse_single_token(t)
        if parsed is not None:
            items.append(parsed)
    return _dedup_items(items)


def _split_profiles_suffix(token: str) -> tuple[str, list[str]]:
    """Split `name(profile1, profile2)` into ("name", ["profile1", "profile2"])."""
    match = PROFILE_SUFFIX_RE.match(token or "")
    if not match:
        return (token or "").strip(), []
    profiles = [p.strip() for p in match.group("profiles").split(",") if p.strip()]
    return match.group("base").strip(), profiles


def _split_group_suffix(token: str) -> tuple[str, str]:
    """Split `name[Channel group]` into ("name", "Channel group")."""
    match = GROUP_SUFFIX_RE.match(token or "")
    if not match:
        return (token or "").strip(), ""
    return match.group("base").strip(), match.group("group").strip()


def _split_following_profiles_suffix(token: str) -> tuple[str, list[str]]:
    """Allow a readable space before profiles only for following tokens."""
    match = re.match(r"^(?P<base>following(?::[^()]*)?)\s+\((?P<profiles>[^()]*)\)\s*$", token or "", re.I)
    if not match:
        return token, []
    profiles = [p.strip() for p in match.group("profiles").split(",") if p.strip()]
    return match.group("base").strip(), profiles


def _split_commas_outside_parens(line: str) -> list[str]:
    """Split on commas, but never inside a (profile, list) suffix."""
    parts: list[str] = []
    current: list[str] = []
    depth = 0
    for ch in line:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        elif ch == "," and depth == 0:
            parts.append("".join(current))
            current = []
            continue
        current.append(ch)
    parts.append("".join(current))
    return parts


def _iter_input_tokens(raw: str):
    for line in raw.replace("\r", "\n").replace(";", "\n").split("\n"):
        line = line.strip()
        if not line:
            continue
        parts = [part.strip() for part in _split_commas_outside_parens(line) if part.strip()]
        index = 0
        while index < len(parts):
            token = parts[index]
            if token.lower().startswith("top:"):
                while index + 1 < len(parts) and not _top_token_has_limit(token):
                    continuation, _profiles = _split_profiles_suffix(parts[index + 1])
                    if not re.fullmatch(r"[A-Za-z][A-Za-z-]{1,4}(?::\d+)?", continuation):
                        break
                    index += 1
                    token = f"{token},{parts[index]}"
            yield token
            index += 1


def _top_token_has_limit(token: str) -> bool:
    base, _profiles = _split_profiles_suffix(token)
    return any(part.strip().isdigit() for part in base[4:].split(":"))


def _parse_single_token(t: str) -> dict | None:
    base, group = _split_group_suffix(t)
    following_base, profiles = _split_following_profiles_suffix(base)
    if following_base == base:
        base, profiles = _split_profiles_suffix(base)
    else:
        base = following_base
    item = _parse_token_body(base)
    if item is not None and profiles:
        item["profiles"] = profiles
    if item is not None and group:
        item["group"] = group
    return item


def _parse_token_body(t: str) -> dict | None:
    low = t.lower()
    if low == "following":
        return {"type": "following", "token": ""}
    if low.startswith("following:"):
        token = (t[len("following:"):] or "").strip()
        if any(char.isspace() or char in ",;()[]" for char in token):
            token = ""
        return {"type": "following", "token": token}
    if low.startswith("game:"):
        rest = t[5:].strip()
        if not rest:
            return None
        # last `:N` is interpreted as limit if it's a number
        name, limit = _split_trailing_limit(rest, default=10)
        return {"type": "game", "value": name, "limit": limit}
    if low == "top":
        return {"type": "top", "languages": [], "limit": 10}
    if low.startswith("top:"):
        rest = t[4:].strip()
        # forms: "25", "de", "de:25"
        if not rest:
            return {"type": "top", "languages": [], "limit": 10}
        parts = [p.strip() for p in rest.split(":") if p.strip()]
        languages: list[str] = []
        limit = 10
        for p in parts:
            if p.isdigit():
                limit = int(p)
            else:
                languages.extend(s.strip().lower() for s in p.split(",") if s.strip())
        return {"type": "top", "languages": languages, "limit": limit}
    if low.startswith("search:"):
        rest = t[7:].strip()
        if not rest:
            return None
        name, limit = _split_trailing_limit(rest, default=10)
        return {"type": "search", "value": name, "limit": limit}

    if "/" in t:
        t = t.rstrip("/").rsplit("/", 1)[-1]
    login = t.lower()
    if not login.replace("_", "").isalnum():
        return None
    return {"type": "login", "value": login}


def _split_trailing_limit(text: str, *, default: int) -> tuple[str, int]:
    if ":" in text:
        head, tail = text.rsplit(":", 1)
        tail = tail.strip()
        if tail.isdigit():
            return head.strip(), max(1, min(100, int(tail)))
    return text.strip(), default


def _dedup_items(items: list[dict]) -> list[dict]:
    seen: dict = {}
    out: list[dict] = []
    for item in items:
        if item["type"] == "login":
            key = ("login", item["value"], item.get("group") or "")
        elif item["type"] == "game":
            key = ("game", item["value"].lower(), item["limit"], item.get("group") or "")
        elif item["type"] == "top":
            key = ("top", tuple(sorted(item["languages"])), item["limit"], item.get("group") or "")
        elif item["type"] == "search":
            key = ("search", item["value"].lower(), item["limit"], item.get("group") or "")
        elif item["type"] == "following":
            key = ("following", item.get("token") or "", item.get("group") or "")
        else:
            continue
        existing = seen.get(key)
        if existing is not None:
            # Same token listed twice: keep one entry, union the profiles.
            for profile in item.get("profiles") or []:
                merged = existing.setdefault("profiles", [])
                if profile not in merged:
                    merged.append(profile)
            continue
        seen[key] = item
        out.append(item)
    return out


def resolve_logins(
    client: TwitchClient,
    items: list[dict],
    *,
    following_access_tokens: dict[str, str] | None = None,
) -> tuple[list[str], dict[str, list[str]], dict[str, str]]:
    """Resolve items into logins plus profile and channel-group mappings."""
    seen: set[str] = set()
    out: list[str] = []
    profiles_by_login: dict[str, list[str]] = {}
    groups_by_login: dict[str, str] = {}
    for item in items:
        candidates: Iterable[str] = ()
        if item["type"] == "login":
            candidates = [item["value"]]
        elif item["type"] == "game":
            candidates = client.streams_in_game(item["value"], limit=item["limit"])
        elif item["type"] == "top":
            candidates = client.top_streams(
                languages=item.get("languages") or (),
                limit=item["limit"],
            )
        elif item["type"] == "search":
            candidates = client.search_channels(item["value"], limit=item["limit"])
        elif item["type"] == "following":
            access_token = (following_access_tokens or {}).get(item.get("token") or "")
            candidates = client.followed_channels(access_token) if access_token else ()

        item_profiles = item.get("profiles") or []
        for login in candidates:
            login = (login or "").strip().lower()
            if not login:
                continue
            if not login.replace("_", "").isalnum():
                continue
            if login not in seen:
                seen.add(login)
                out.append(login)
            # The first entry owns group selection, including the empty value
            # that means use the global default group. This lets an explicit
            # channel above a later following token retain the default group.
            if login not in groups_by_login:
                groups_by_login[login] = item.get("group") or ""
            if item_profiles:
                merged = profiles_by_login.setdefault(login, [])
                for profile in item_profiles:
                    if profile not in merged:
                        merged.append(profile)
    return out, profiles_by_login, groups_by_login


def render_box_art(url: str, width: int = 272, height: int = 380) -> str:
    if not url:
        return ""
    rendered = url.replace("{width}", str(width)).replace("{height}", str(height))
    return BOX_ART_SIZE_RE.sub(f"-{width}x{height}", rendered, count=1)
