"""Anonymous Kick channel metadata."""

from __future__ import annotations

import logging

import requests

from .stream_sources import StreamSnapshot, source_url

logger = logging.getLogger(__name__)

CHANNEL_URL = "https://kick.com/api/v2/channels/{slug}"


class KickClient:
    def __init__(self, session: requests.Session | None = None, *, timeout: int = 10):
        self.session = session or requests.Session()
        self.timeout = timeout

    def poll(self, slug: str) -> StreamSnapshot | None:
        try:
            response = self.session.get(CHANNEL_URL.format(slug=slug), timeout=self.timeout)
            if response.status_code != 200:
                return None
            data = response.json()
        except (requests.RequestException, ValueError):
            logger.warning("Kick channel metadata request failed for %s", slug)
            return None
        if not isinstance(data, dict):
            return None
        user = data.get("user") or {}
        stream = data.get("livestream")
        if stream is not None and not isinstance(stream, dict):
            return None
        category = (stream or {}).get("categories") or []
        first_category = category[0] if category and isinstance(category[0], dict) else {}
        return StreamSnapshot(
            platform="kick",
            slug=slug,
            display_name=str(data.get("username") or user.get("username") or slug),
            live_state="live" if stream else "offline",
            source_url=source_url("kick", slug),
            description=str(user.get("bio") or ""),
            profile_image_url=str(user.get("profile_pic") or ""),
            stream_title=str((stream or {}).get("session_title") or ""),
            category=str(first_category.get("name") or ""),
            started_at=str((stream or {}).get("created_at") or ""),
            viewer_count=int((stream or {}).get("viewer_count") or 0),
            program_image_url=str(first_category.get("thumbnail") or ""),
            provider_channel_id=str(data.get("id") or ""),
            active_stream_id=str((stream or {}).get("slug") or ""),
        )
