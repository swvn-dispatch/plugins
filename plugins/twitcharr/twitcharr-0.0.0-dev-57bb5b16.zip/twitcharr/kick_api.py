"""Anonymous Kick channel metadata."""

from __future__ import annotations

import logging

import requests

from .stream_sources import StreamSnapshot, source_url

logger = logging.getLogger(__name__)

CHANNEL_URL = "https://kick.com/api/v2/channels/{slug}"
LIVESTREAM_URL = "https://web.kick.com/api/v1/channels/{slug}/livestream"


def _image_url(value) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        return _image_url(value.get("url") or value.get("src"))
    return ""


def _category_image(category: dict, recent_categories) -> str:
    image = _image_url(category.get("thumbnail")) or _image_url(category.get("banner"))
    if image or not isinstance(recent_categories, list):
        return image
    for recent in recent_categories:
        if not isinstance(recent, dict):
            continue
        if category.get("id") is not None and recent.get("id") == category["id"]:
            return _image_url(recent.get("thumbnail")) or _image_url(recent.get("banner"))
    return ""


class KickClient:
    def __init__(self, session: requests.Session | None = None, *, timeout: int = 10):
        self.session = session or requests.Session()
        self.timeout = timeout

    def _live_image(self, slug: str) -> str:
        try:
            response = self.session.get(LIVESTREAM_URL.format(slug=slug), timeout=self.timeout)
            if response.status_code != 200:
                return ""
            data = response.json()
            data = data.get("data") if isinstance(data, dict) else None
            stream = data.get("livestream") if isinstance(data, dict) else None
            return _image_url(stream.get("thumbnail")) if isinstance(stream, dict) else ""
        except (requests.RequestException, ValueError):
            logger.warning("Kick livestream thumbnail request failed for %s", slug)
            return ""

    def poll(self, slug: str) -> StreamSnapshot | None:
        try:
            response = self.session.get(CHANNEL_URL.format(slug=slug), timeout=self.timeout)
            if response.status_code != 200:
                return None
            data = response.json()
        except (requests.RequestException, ValueError):
            logger.warning("Kick channel metadata request failed for %s", slug)
            return None
        if not isinstance(data, dict):
            return None
        user = data.get("user") or {}
        stream = data.get("livestream")
        if stream is not None and not isinstance(stream, dict):
            return None
        category = (stream or {}).get("categories") or []
        if not isinstance(category, list):
            category = []
        first_category = category[0] if category and isinstance(category[0], dict) else {}
        return StreamSnapshot(
            platform="kick",
            slug=slug,
            display_name=str(data.get("username") or user.get("username") or slug),
            live_state="live" if stream else "offline",
            source_url=source_url("kick", slug),
            description=str(user.get("bio") or ""),
            profile_image_url=str(user.get("profile_pic") or ""),
            stream_title=str((stream or {}).get("session_title") or ""),
            category=str(first_category.get("name") or ""),
            started_at=str((stream or {}).get("created_at") or ""),
            viewer_count=int((stream or {}).get("viewer_count") or 0),
            program_image_url=_category_image(first_category, data.get("recent_categories")),
            provider_channel_id=str(data.get("id") or ""),
            active_stream_id=str((stream or {}).get("slug") or ""),
            live_image_url=self._live_image(slug) if stream else "",
        )
